from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from app.providers.search import scholarly_search

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"
app = FastAPI(title="Research OS", version="1.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ResearchRequest(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    limit: int = Field(default=10, ge=1, le=20)

@app.get("/health")
def health():
    return {"status": "ok", "version": "1.2.0", "service": "Research OS"}

@app.post("/research")
async def research(req: ResearchRequest):
    try:
        results = await scholarly_search(req.question, req.limit)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Scientific providers unavailable: {exc}")
    return {"question": req.question, "stage": "scholarly_discovery", "sources": results, "count": len(results), "next_stage": "evidence_extraction"}

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")
