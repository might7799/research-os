import asyncio
import httpx

TIMEOUT = httpx.Timeout(15.0, connect=8.0)

async def _get(client, url, params):
    try:
        r = await client.get(url, params=params, headers={"User-Agent": "ResearchOS/1.2"})
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"_error": str(e)}

def _norm(provider, item):
    if provider == "openalex":
        return {"provider": provider, "title": item.get("title"), "year": item.get("publication_year"), "doi": item.get("doi"), "url": (item.get("primary_location") or {}).get("landing_page_url") or item.get("id"), "authors": ", ".join((a.get("author") or {}).get("display_name", "") for a in item.get("authorships", []))}
    if provider == "semantic_scholar":
        return {"provider": provider, "title": item.get("title"), "year": item.get("year"), "doi": (item.get("externalIds") or {}).get("DOI"), "url": item.get("url"), "authors": ", ".join(a.get("name", "") for a in item.get("authors", []))}
    date_parts = (item.get("published-print") or item.get("published-online") or {}).get("date-parts", [])
    year = date_parts[0][0] if date_parts and date_parts[0] else None
    return {"provider": provider, "title": item.get("title"), "year": year, "doi": item.get("DOI"), "url": item.get("URL"), "authors": ", ".join((a.get("given", "") + " " + a.get("family", "")).strip() for a in item.get("author", []))}

async def scholarly_search(query: str, limit: int = 10):
    per = max(1, min(limit, 20))
    async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as client:
        oa, ss, cr = await asyncio.gather(
            _get(client, "https://api.openalex.org/works", {"search": query, "per-page": per}),
            _get(client, "https://api.semanticscholar.org/graph/v1/paper/search", {"query": query, "limit": per, "fields": "title,year,authors,externalIds,url"}),
            _get(client, "https://api.crossref.org/works", {"query": query, "rows": per}),
        )
    out = []
    out += [_norm("openalex", x) for x in oa.get("results", []) if isinstance(x, dict)]
    out += [_norm("semantic_scholar", x) for x in ss.get("data", []) if isinstance(x, dict)]
    out += [_norm("crossref", x) for x in (cr.get("message", {}).get("items", []) if isinstance(cr, dict) else []) if isinstance(x, dict)]
    seen = set(); dedup = []
    for x in out:
        key = (x.get("doi") or "" or x.get("title") or "").lower().strip()
        if not key or key not in seen:
            seen.add(key); dedup.append(x)
    return dedup[:per]
